package streamsIterateursSol;

public enum Categorie {
	A,B,C
}
