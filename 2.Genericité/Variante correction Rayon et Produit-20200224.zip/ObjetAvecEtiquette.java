package genericiteBornee;

public interface ObjetAvecEtiquette<TypeEtiquette> {
	TypeEtiquette etiquette();
}
